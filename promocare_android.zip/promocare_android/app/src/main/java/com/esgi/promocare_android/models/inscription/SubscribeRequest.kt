package com.esgi.promocare_android.models.inscription

data class SubscribeRequest(val email : String, val password : String, val first_name : String, val last_name : String)

