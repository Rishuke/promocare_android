package com.esgi.promocare_android.models.login

data class LoginRequest(val email:String,val password:String) {}
