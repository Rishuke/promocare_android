package com.esgi.promocare_android.models.conversations

data class NoConvDto(
    val convId : String?
)
