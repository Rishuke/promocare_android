package com.esgi.promocare_android.models.inscription

data class SubscribeCompanyResponse(
    val message: String,
    val token: String,
    val id:String

)
