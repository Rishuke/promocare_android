package com.esgi.promocare_android.models.inscription

data class SubscribeCompanyRequest(val email : String, val password : String, val company_name : String, val siret_number : String, val location : String)