package com.esgi.promocare_android.network

object Credential {
    var token : String = "Bearer "
}