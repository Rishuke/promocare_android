package com.esgi.promocare_android.models.inscription

data class SubscribeResponse(
    val message: String,
    val token: String,
    val id:String
)