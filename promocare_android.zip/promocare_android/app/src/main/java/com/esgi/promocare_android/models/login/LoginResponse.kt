package com.esgi.promocare_android.models.login

data class LoginResponse(
    val message: String,
    val token: String,
    val id:String
)
